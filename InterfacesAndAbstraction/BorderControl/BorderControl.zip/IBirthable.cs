﻿namespace BorderControl
{
    public interface IBirthable
    {
        string BirthDate { get; set; }
    }
}