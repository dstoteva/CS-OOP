﻿namespace BorderControl
{
    public interface IAgeable
    {
        int Age { get; set; }
    }
}