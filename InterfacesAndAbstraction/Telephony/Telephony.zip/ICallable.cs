﻿namespace Telephony
{
    internal interface ICallable
    {
        string Call();
    }
}