﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cars
{
    interface IElectricCar
    {
        int Battery { get; set; }
    }
}
