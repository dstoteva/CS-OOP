﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelReservation
{
    public enum DiscountType
    {
        VIP = 20,
        SecondVisit = 10,
        no = 0
    }
}
