﻿using InfernoInfinity.Controllers;
using System;

namespace InfernoInfinity
{
    class Program
    {
        static void Main(string[] args)
        {
            new Engine().Run();
        }
    }
}
