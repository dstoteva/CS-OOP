﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InfernoInfinity.IO
{
    public class OutputWriter
    {
        internal void WriteLine(string text) => Console.WriteLine(text);
    }
}
