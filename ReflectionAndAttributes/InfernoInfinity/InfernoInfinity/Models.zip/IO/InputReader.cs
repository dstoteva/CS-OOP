﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InfernoInfinity.IO
{
    public class InputReader
    {
        internal string ReadLine() => Console.ReadLine();
    }
}
