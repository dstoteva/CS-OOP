﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficLights
{
    public enum Light
    {
        Red = 1,
        Green = 2,
        Yellow = 3
    }
}
